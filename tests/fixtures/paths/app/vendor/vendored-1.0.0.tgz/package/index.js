module.exports = "from a tarball inside the project";
